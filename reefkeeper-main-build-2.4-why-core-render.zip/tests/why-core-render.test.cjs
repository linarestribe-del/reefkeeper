const fs = require('fs');
const s = fs.readFileSync('app.js','utf8');
function ok(c,m){if(!c) throw new Error(m)}
ok(s.includes("options.showWhy"), 'appendMsg does not render Why from options');
ok(s.includes("<strong>Build:</strong> 2.4"), 'Build marker missing');
ok(s.includes("{ showWhy: tankContextWasUsed }"), 'sendChat does not pass Why flag into core renderer');
ok(!s.includes("attachAIWhy(aiMessageEl, tankContextWasUsed)"), 'legacy post-render attachment remains');
console.log('Why core-render regression passed.');
