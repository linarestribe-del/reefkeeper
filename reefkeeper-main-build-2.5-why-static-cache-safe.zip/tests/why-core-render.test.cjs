const fs = require('fs');
const html = fs.readFileSync('index.html','utf8');
const app = fs.readFileSync('app-build-2-5.js','utf8');
function ok(c,m){if(!c) throw new Error(m)}
ok(html.includes('latest-ai-why-wrap'), 'Static Why control missing');
ok(html.includes('latest-ai-why-panel'), 'Static Why panel missing');
ok(html.includes("window.toggleLatestAIWhy"), 'Independent Why toggle missing');
ok(html.includes("var complete=Boolean(hasUser&&last&&last.classList.contains('ai'))"), 'Latest-answer completion check missing');
ok(!app.includes("{ showWhy: tankContextWasUsed }"), 'sendChat still relies on the fragile in-bubble Why path');
ok(html.indexOf('latest-ai-why-wrap') < html.indexOf('model-selector-wrap'), 'Why control must appear before the Answer selector');
console.log('Why static-render regression passed.');
